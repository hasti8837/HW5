#include<stdio.h>
#include<math.h>
int solver( double a, double b,double c,double *root1, double *root2);
 int main(){
    double a,b,c;
    printf("Enter coefdicients of the quadratic equation(a*(x*x)+b*x+c): ");
    scanf("%lf %lf %lf",&a,&b,&c );
    if(a==0&&b==0){
      printf("Please enter correct numbers.");
    }
    double root1,root2;
    int numroots = solver(a,b,c,&root1,&root2);
    if(numroots==0){
      printf("This equation has no real roots.\n");
    }else{
      printf("Number of real roots: %d\n",numroots);
      if(numroots==1){
         printf("Root: %lf\n",root1);
      }else{
         printf("Root 1:%lf\n",root1);
         printf("Root 2:%lf\n",root2);
      }
    }
    return 0;
 }
int solver(double a, double b, double c,double *root1, double *root2){
   double discriminant = b*b - 4*a*c;
   if(discriminant > 0){
      *root1=(-b + sqrt(discriminant))/(2*a);
      *root2=(-b + sqrt(discriminant))/(2*a);
      return 2;
   }else if (discriminant==0){
      *root1=-b / (2*a);
      return 1;
   } else{
      return 0;
   }
}
