#include<stdio.h>//هستی دلفان         40223033
int main (){
    int n;
    printf("Enter a positive integer: ");
    scanf("%d",&n);
    char expression[n+1];
    printf("Enter a textual expression containing %d characters without blank space: ",n);
    scanf("%s",expression);
    printf("Original expression: %s\n",expression);
    int i,j,count=0;
    for(i=0;i<n-1;i++){
        if(expression[i]==expression[i+1]){
            count++;
            for(j=i;j<n-1;j++){
         expression[j]=expression[j+2];   
            }   
           
            n-=2;
            expression[n]= '\0 ';
            
            printf("Step %d: %s\n",count,expression);
            i=-1;      
            
        }
    }
    printf("Final expression: %s\n",expression);
    return(0);
}
